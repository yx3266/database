from django.apps import AppConfig


class SearchArticleConfig(AppConfig):
    name = 'search_article'
