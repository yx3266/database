from django.contrib import admin

# Register your models here.
from .models import Person, Article, Category

class PersonAdmin(admin.ModelAdmin):
    list_display =('id','__str__')
    search_fields = ['user__username']
    list_per_page = 10

class ArticleAdmin(admin.ModelAdmin):
    list_display = ('id', 'article_name', 'article_category', 'author', 'good_num', 'article_rank')
    search_fields = ['article_name']
    list_per_page = 10

class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'category_name', 'number')
    search_fields = ['category']
    list_per_page = 10


admin.site.register(Person, PersonAdmin)
admin.site.register(Article, ArticleAdmin)
admin.site.register(Category, CategoryAdmin)