from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Person(models.Model):
    """
    用户类，与User为一对一关系
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    person_rank = models.IntegerField(unique=False, verbose_name='用户等级', default= 0)

    def __str__(self):
        return  (self.user.username)

class Article(models.Model):
    """
    文章类
    有上传者，文章名称，文章板块，作者，简介，点赞数/浏览数，等级等属性
    """
    user = models.ForeignKey(User, verbose_name='上传者', related_name='articles', on_delete=models.CASCADE) #related_name是否需要
    article_name = models.CharField('文章题目', max_length=40, unique=True,blank=False)
    article_category = models.ForeignKey('Category', verbose_name='文章板块', on_delete=models.CASCADE)
    author = models.CharField('文章作者', max_length=40, unique=True, blank=False)
    introduction = models.TextField('文章简介')
    good_num = models.IntegerField(default=0, verbose_name='点赞数或浏览数')
    article_rank = models.IntegerField(unique=False, verbose_name='文章等级', default=0)

    def __str__(self):
        return  (self.article_name)

class Category(models.Model):
    """
    文章板块
    """
    category_name = models.CharField(max_length=40, unique=True, verbose_name='版块名称')
    number = models.IntegerField(unique=True, verbose_name='板块序号')

    def __str__(self):
        return (self.category_name)