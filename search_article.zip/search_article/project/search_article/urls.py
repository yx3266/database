from django.urls import path
from django.views.generic.base import RedirectView
from . import views

app_name = 'search_article'
urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.login, name='login'),
    path('register/', views.register, name='register'),
    #path('logout/', views.logout, name='logout'),
    #path('register/', views.register, name='register'),
    #path('search/', views.search, name='search'),
    path('about/',views.about, name='about'),
    path('contact-us/', views.contact_us, name='contact-us'),
    #path('upload/', views.ask, name='ask'),
    #path('myzone/', views.myzone, name='myzone'),
    #path('article/', views.article, name='article'),
]