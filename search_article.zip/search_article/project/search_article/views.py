from django.shortcuts import render

# Create your views here.

# -*- coding: utf-8 -*-

from django.shortcuts import render, get_object_or_404
from django.http import HttpResponseRedirect
from django.urls import reverse
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import RegistrationForm, LoginForm
from .models import *
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

def index(request):
    if request.user.is_authenticated:
        username = request.user.username
        is_logged_in = True
    else:
        username = '未登录'
        is_logged_in = False
    context = {
        'username':username,
        'is_logged_in': is_logged_in,
    }
    #return HttpResponseRedirect(reverse('search_article:index'))
    return render(request, 'index.html', context)

def register(request):
    form1 = LoginForm()
    form2 = RegistrationForm()
    context = {
        'loginForm': form1,
        'registrationForm': form2,
    }
    if request.method == 'POST':
        form2 = RegistrationForm(request.POST)
        if form2.is_valid():
            username = form2.cleaned_data['username']
            email = form2.cleaned_data['email']
            password = form2.cleaned_data['password2']
            user = User.objects.create_user(username=username, email=email, password=password)
            person = Person(user=user)
            person.save()
            context['loginMessage'] = "注册成功! 请登录"
            return render(request, 'login_register.html', context)
        else:
            context['loginMessage'] = "注册失败, 可能的原因有: 1. 用户名已被注册 2. 密码太长或太短 3. 邮箱格式不正确"
            context['registerMessage'] = "注册失败, 请重新填写表单"
            return render(request, 'login_register.html', context)
    else:
        return render(request, 'login_register.html',context)


def login(request):
    form1 = LoginForm()
    form2 = RegistrationForm()
    context = {
        'loginForm': form1,
        'registrationForm': form2,
    }
    if request.method == 'POST':
        form1 = LoginForm(request.POST)
        if form1.is_valid():
            username = form1.cleaned_data['username']
            password = form1.cleaned_data['password']

            user = auth.authenticate(username=username, password=password)
            if user is not None and user.is_active:
                auth.login(request, user)
                return HttpResponseRedirect(reverse('search_article:index'))
            else:
                context['loginMessage'] = "密码或用户名错误, 请重试"
                return render(request, 'login_register.html', context)
        else:
            context['loginMessage'] = "密码或用户名错误, 请重试"
            return render(request, 'login_register.html', context)
    else:
        return render(request, 'login_register.html', context)


def about(request):
    if request.user.is_authenticated:
        username = request.user.username
        is_logged_in = True
    else:
        username = '未登录'
        is_logged_in = False
    context = {
        'username':username,
        'is_logged_in': is_logged_in,
    }
    #return HttpResponseRedirect(reverse('search_article:index'))
    return render(request, 'about.html', context)


def contact_us(request):
    if request.user.is_authenticated:
        username = request.user.username
        is_logged_in = True
    else:
        username = '未登录'
        is_logged_in = False
    context = {
        'username':username,
        'is_logged_in': is_logged_in,
    }
    #return HttpResponseRedirect(reverse('search_article:index'))
    return render(request, 'contact-us.html', context)